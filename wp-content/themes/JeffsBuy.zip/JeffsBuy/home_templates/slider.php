<?php global $deeplive; ?>
<!-- Slider Section Start -->
<div class="banner">
        <div class="container">
            <div class="banner_desc">
                <h1><?php echo $deeplive['banner-h1']; ?></h1>
                <h2><?php echo $deeplive['banner-para']; ?></h2>
            </div>
        </div>
    </div>
<!-- Slider Section End -->