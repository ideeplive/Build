<?php global $deeplive; ?>
<div class="col-md-4 box_3">
    <h3><?php echo $deeplive['footer-right-title']; ?></h3>
    <ul class="list_1">
        <li><a href="https://localhost/jeffsbuy/shop/">Men</a></li>
        <li><a href="https://localhost/jeffsbuy/shop/">Women</a></li>
        <li><a href="https://localhost/jeffsbuy/shop/">Accessories</a></li>
        <li><a href="https://localhost/jeffsbuy/kids/">Kids</a></li>
        <li><a href="https://localhost/jeffsbuy/shop/">Home</a></li>
        <li><a href="https://localhost/jeffsbuy/shop/">Electronics</a></li>
    </ul>
    <ul class="list_1">
        <li><a href="https://localhost/jeffsbuy/shop/"><b>Products</b></a></li>
        <li><a href="https://localhost/jeffsbuy/shop/">cars</a></li>
        <li><a href="https://localhost/jeffsbuy/shop/">Bikes</a></li>
        <li><a href="https://localhost/jeffsbuy/shop/">Real Estate</a></li>
    </ul>
    <div class="clearfix"> </div>
</div>




















