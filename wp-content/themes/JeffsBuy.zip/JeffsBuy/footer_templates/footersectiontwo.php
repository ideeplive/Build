<?php global $deeplive; ?>
<div class="col-md-4 box_3">
    <h3><?php echo $deeplive['footer-center-title']; ?></h3>
    <?php echo $deeplive['footer-center-des']; ?>
</div>





















