<?php global $deeplive; ?>
<div class="col-md-4 box_3">
        <h3><?php echo $deeplive['footer-left-title']; ?></h3>
        <?php echo $deeplive['footer-left-des']; ?>
        <!--
<ul class="footer_social">
    <li><a href=""> <i class="fb"> </i> </a></li>
    <li><a href=""><i class="tw"> </i> </a></li>
    <li><a href=""><i class="google"> </i> </a></li>
    <li><a href=""><i class="instagram"> </i> </a></li>
</ul>
-->
</div>



















