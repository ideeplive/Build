<?php global $deeplive; ?>
<?php /* Template Name: Coming Soon */ ?>
<?php get_header(); ?>
    <div class="single_top">
        <div class="container">
            <div class="error-404 text-center">
                <h1><?php echo $deeplive['coming-soon-title']; ?></h1>
                <p><?php echo $deeplive['coming-soon-des']; ?></p>
            </div>
        </div>
    </div>
    </div>
    </div>
<!--------------Footer--------------->
<?php get_footer(); ?>